// const notificationModal = document.querySelector('.notification__modal')
// const notificationBtn = document.querySelector('.notification__btn')

// notificationBtn.addEventListener('click', () => {
//     notificationModal.classList.toggle('notification__modal-on')
// })